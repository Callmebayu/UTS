package com.example.makanandaerah;

public class myitem {
    static int[] gambar = {
            R.drawable.grombyang, R.drawable.gulai, R.drawable.sate, R.drawable.lontong,
            R.drawable.soto
    };

    static String[] Headline = {
            "Nasi Grombyang", "Gulai Kambing", "Sate Loso", "Lontong Dekem", "Soto Babat"
    };
    static String[] Harga = {
            "Rp. 20.000","Rp. 25.000","Rp. 15.000","Rp. 17.000","Rp. 16.000"
    };

}
