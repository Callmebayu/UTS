package com.example.makanandaerah;

public class itemModel {
    String name;
    String harga;
    int image;

    public itemModel(String name, String harga, int image) {
        this.name = name;
        this.harga = harga;
        this.image = image;

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getHarga() {
        return harga;
    }

    public void setHarga(String harga) {
        this.harga = harga;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }
}