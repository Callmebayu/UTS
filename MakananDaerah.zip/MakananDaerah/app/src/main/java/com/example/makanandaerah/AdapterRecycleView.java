package com.example.makanandaerah;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AdapterRecycleView extends RecyclerView.Adapter<AdapterRecycleView.ViewHolder> {
    private ArrayList<itemModel> dataproduk;
    private Context context;

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView textProduk;
        TextView textHarga;
        ImageView fotoProduk;
        LinearLayoutCompat constraintLayout;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            textProduk = itemView.findViewById(R.id.textProduk);
            textHarga = itemView.findViewById(R.id.textHarga);
            fotoProduk = itemView.findViewById(R.id.fotoProduk);
            constraintLayout = itemView.findViewById(R.id.constraintLayout);


        }
    }

    AdapterRecycleView(Context context, ArrayList<itemModel>dataproduk){
        this.dataproduk = dataproduk;
        this.context = context;
    }
    @NonNull
    @Override
    public AdapterRecycleView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.frontviewadapter, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterRecycleView.ViewHolder holder, int position) {
        TextView textProduk = holder.textProduk;
        TextView textHarga = holder.textHarga;
        ImageView fotoProduk = holder.fotoProduk;

        textProduk.setText(dataproduk.get(position).getName());
        textHarga.setText(dataproduk.get(position).getHarga());
        fotoProduk.setImageResource(dataproduk.get(position).getImage());

        holder.constraintLayout.setOnClickListener(v ->{
            Toast.makeText(context, dataproduk.get(position).getName(), Toast.LENGTH_SHORT).show();

            if(dataproduk.get(position).getName().equals("Nasi Grombyang")){
                context.startActivity(new Intent(context, GrombyangActivity.class));
            }
            if(dataproduk.get(position).getName().equals("Gulai Kambing")){
                context.startActivity(new Intent(context, GulaiActivity.class));
            }
            if(dataproduk.get(position).getName().equals("Sate Loso")){
                context.startActivity(new Intent(context, SateActivity.class));
            }
            if(dataproduk.get(position).getName().equals("Lontong Dekem")){
                context.startActivity(new Intent(context, LontongActivity.class));
            }
            if(dataproduk.get(position).getName().equals("Soto Babat")){
                context.startActivity(new Intent(context, SotoActivity.class));
            }

        });


    }

    @Override
    public int getItemCount() {
        return dataproduk.size();
    }

}
